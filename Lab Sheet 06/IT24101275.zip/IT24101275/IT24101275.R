setwd("C:\\Users\\DELL\\Desktop\\IT24101275")
##Q01
#(i)
##Binomial Distribution
#Hear,random variable x has binomial distribution with n=50 and p=0.85
1-pbinom(46,50,0,85,lower.tail=TRUE)


##Q2
#(i)X=number_of_calls in one_hour

#(ii)Poisson distribution
#Here,random variable x has poisson distribution with lambda=12
dpois(15,12)
